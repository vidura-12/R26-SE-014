from pathlib import Path

import joblib
import pandas as pd


# ============================================================
# BASE DIRECTORY
# ============================================================
# predict.py is located at:
#
# backend/
#   services/
#       predict.py
#
# Therefore:
# parent      = services/
# parent.parent = backend/
#
# This makes the paths work both locally on Windows and
# when deployed to Azure Linux.
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent


# ============================================================
# MODEL FILE PATHS
# ============================================================

MODEL_PATH = BASE_DIR / "models" / "xgboost_model.pkl"

ENCODER_PATH = BASE_DIR / "models" / "label_encoder.pkl"

FEATURE_COLUMNS_PATH = (
    BASE_DIR / "models" / "feature_columns.pkl"
)


# ============================================================
# CHECK REQUIRED FILES
# ============================================================

if not MODEL_PATH.exists():
    raise FileNotFoundError(
        f"XGBoost model not found: {MODEL_PATH}"
    )

if not ENCODER_PATH.exists():
    raise FileNotFoundError(
        f"Label encoder not found: {ENCODER_PATH}"
    )

if not FEATURE_COLUMNS_PATH.exists():
    raise FileNotFoundError(
        f"Feature columns file not found: {FEATURE_COLUMNS_PATH}"
    )


# ============================================================
# LOAD MODEL, ENCODER, AND FEATURE COLUMNS
# ============================================================
# These are loaded once when the FastAPI application starts.
# ============================================================

model = joblib.load(MODEL_PATH)

encoder = joblib.load(ENCODER_PATH)

feature_cols = joblib.load(FEATURE_COLUMNS_PATH)


# ============================================================
# BUILD FULL FEATURE VECTOR
# ============================================================

def build_full_features(
    ph,
    moisture,
    temp,
    rainfall=180,
    sunlight=7.5,
    age=8,
    growth_rate=3.5,
    bark_yield=275,
):
    """
    Build the complete feature vector required by the
    trained XGBoost model.

    The API currently receives:
        - Soil pH
        - Soil moisture
        - Soil temperature

    Other model features use default values unless they are
    supplied directly to this function.
    """

    # ========================================================
    # RAW INPUT + DEFAULT FEATURES
    # ========================================================

    data = {
        "Soil_pH": ph,
        "Soil_Moisture_VWC_%": moisture,
        "Soil_Temp_C": temp,

        "Rainfall_mm_month": rainfall,
        "Sunlight_hrs_day": sunlight,
        "Plant_Age_years": age,
        "Growth_Rate_cm_month": growth_rate,
        "Annual_Bark_Yield_g_plant": bark_yield,

        # ----------------------------------------------------
        # STRESS FEATURES
        # ----------------------------------------------------

        "Moisture_stress": (
            1 if (moisture < 22 or moisture > 38) else 0
        ),

        "Temp_stress": (
            1 if temp > 30 else 0
        ),

        "Combined_stress_score": (
            (1 if (moisture < 22 or moisture > 38) else 0)
            + (1 if temp > 30 else 0)
            + (1 if ph < 5.0 else 0)
        ),

        # ----------------------------------------------------
        # DERIVED FEATURES
        # ----------------------------------------------------

        "Yield_per_age": (
            bark_yield / age if age != 0 else 0
        ),

        "Growth_efficiency": (
            growth_rate / age if age != 0 else 0
        ),
    }


    # ========================================================
    # CREATE DATAFRAME
    # ========================================================

    df_temp = pd.DataFrame([data])


    # ========================================================
    # pH CATEGORY
    # ========================================================

    df_temp["pH_category"] = pd.cut(
        df_temp["Soil_pH"],
        bins=[0, 5.0, 6.5, 14],
        labels=[
            "Acidic",
            "Optimal_pH",
            "Alkaline",
        ],
    )


    # ========================================================
    # RAINFALL CATEGORY
    # ========================================================

    df_temp["Rainfall_category"] = pd.cut(
        df_temp["Rainfall_mm_month"],
        bins=[0, 100, 200, 300, 500],
        labels=[
            "Low",
            "Medium",
            "High",
            "Very_High",
        ],
    )


    # ========================================================
    # PLANT AGE CATEGORY
    # ========================================================

    df_temp["Age_group"] = pd.cut(
        df_temp["Plant_Age_years"],
        bins=[0, 3, 8, 12, 20],
        labels=[
            "Young",
            "Mature",
            "Old",
            "Very_Old",
        ],
    )


    # ========================================================
    # ONE-HOT ENCODING
    # ========================================================

    df_temp = pd.get_dummies(
        df_temp,
        columns=[
            "pH_category",
            "Rainfall_category",
            "Age_group",
        ],
    )


    # ========================================================
    # ALIGN WITH TRAINING FEATURES
    # ========================================================
    # The trained model expects exactly the same feature
    # columns used during training.
    #
    # If a categorical dummy column is missing from the
    # current input, create it with value 0.
    # ========================================================

    for col in feature_cols:

        if col not in df_temp.columns:
            df_temp[col] = 0


    # ========================================================
    # REMOVE EXTRA COLUMNS
    # ========================================================
    # Return the features in exactly the same order as during
    # model training.
    # ========================================================

    df_temp = df_temp[feature_cols]


    return df_temp


# ============================================================
# PREDICT RISK
# ============================================================

def predict_risk(
    ph,
    moisture,
    temp,
    rainfall=180,
    sunlight=7.5,
    age=8,
    growth_rate=3.5,
    bark_yield=275,
):
    """
    Predict White Root Rot risk from sensor readings.

    Parameters
    ----------
    ph : float
        Soil pH.

    moisture : float
        Soil moisture VWC percentage.

    temp : float
        Soil temperature in Celsius.

    rainfall : float
        Monthly rainfall in mm.

    sunlight : float
        Daily sunlight hours.

    age : float
        Plant age in years.

    growth_rate : float
        Growth rate in cm/month.

    bark_yield : float
        Annual bark yield in grams/plant.

    Returns
    -------
    dict
        {
            "level": prediction label,
            "confidence": confidence percentage,
            "probabilities": probability for each class
        }
    """

    # ========================================================
    # BUILD MODEL INPUT
    # ========================================================

    X = build_full_features(
        ph=ph,
        moisture=moisture,
        temp=temp,
        rainfall=rainfall,
        sunlight=sunlight,
        age=age,
        growth_rate=growth_rate,
        bark_yield=bark_yield,
    )


    # ========================================================
    # PREDICT CLASS
    # ========================================================

    prediction = model.predict(X)


    # ========================================================
    # PREDICT CLASS PROBABILITIES
    # ========================================================

    proba = model.predict_proba(X)[0]


    # ========================================================
    # DECODE PREDICTION
    # ========================================================

    label = encoder.inverse_transform(prediction)


    # ========================================================
    # CONFIDENCE
    # ========================================================

    confidence = int(
        round(max(proba) * 100)
    )


    # ========================================================
    # PROBABILITY BREAKDOWN
    # ========================================================

    probs = {
        encoder.classes_[i]: round(
            float(p),
            3
        )
        for i, p in enumerate(proba)
    }


    # ========================================================
    # RETURN RESULT
    # ========================================================

    return {
        "level": label[0],
        "confidence": confidence,
        "probabilities": probs,
    }